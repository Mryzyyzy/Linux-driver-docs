/*
 * Copyright (c) 2020-2025, Arm Limited. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef ARCH_FEATURES_H
#define ARCH_FEATURES_H

#include <stdbool.h>
#include <stdint.h>

#include <arch_features.h>
#include <arch_helpers.h>
#include <utils_def.h>

static inline bool is_armv7_gentimer_present(void)
{
	/* The Generic Timer is always present in an ARMv8-A implementation */
	return true;
}

static inline bool is_armv8_1_pan_present(void)
{
	u_register_t id_aa64mmfr1_pan =
		EXTRACT(ID_AA64MMFR1_EL1_PAN, read_id_aa64mmfr1_el1());
	return (id_aa64mmfr1_pan >= ID_AA64MMFR1_EL1_PAN_SUPPORTED) &&
		(id_aa64mmfr1_pan <= ID_AA64MMFR1_EL1_PAN3_SUPPORTED);
}

static inline bool is_armv8_1_vhe_present(void)
{
	return ((read_id_aa64mmfr1_el1() >> ID_AA64MMFR1_EL1_VHE_SHIFT) &
		ID_AA64MMFR1_EL1_VHE_MASK) == 1U;
}

static inline bool is_armv8_2_pan2_present(void)
{
	u_register_t id_aa64mmfr1_pan =
		EXTRACT(ID_AA64MMFR1_EL1_PAN, read_id_aa64mmfr1_el1());
	return (id_aa64mmfr1_pan >= ID_AA64MMFR1_EL1_PAN2_SUPPORTED) &&
		(id_aa64mmfr1_pan <= ID_AA64MMFR1_EL1_PAN3_SUPPORTED);
}

static inline bool is_armv8_2_sve_present(void)
{
	return ((read_id_aa64pfr0_el1() >> ID_AA64PFR0_SVE_SHIFT) &
		ID_AA64PFR0_SVE_MASK) == 1U;
}

static inline bool is_feat_advsimd_present(void)
{
	u_register_t id_aa64pfr0_advsimd =
		EXTRACT(ID_AA64PFR0_ADVSIMD, read_id_aa64pfr0_el1());
	return (id_aa64pfr0_advsimd == 0 || id_aa64pfr0_advsimd == 1);
}

static inline bool is_feat_fp_present(void)
{
	u_register_t id_aa64pfr0_fp =
		EXTRACT(ID_AA64PFR0_FP, read_id_aa64pfr0_el1());
	return (id_aa64pfr0_fp == 0 || id_aa64pfr0_fp == 1);
}

static inline bool is_armv8_2_ttcnp_present(void)
{
	return ((read_id_aa64mmfr2_el1() >> ID_AA64MMFR2_EL1_CNP_SHIFT) &
		ID_AA64MMFR2_EL1_CNP_MASK) != 0U;
}

static inline bool is_feat_pacqarma3_present(void)
{
	uint64_t mask_id_aa64isar2 =
		(ID_AA64ISAR2_GPA3_MASK << ID_AA64ISAR2_GPA3_SHIFT) |
		(ID_AA64ISAR2_APA3_MASK << ID_AA64ISAR2_APA3_SHIFT);

	/* If any of the fields is not zero, QARMA3 algorithm is present */
	return (read_id_aa64isar2_el1() & mask_id_aa64isar2) != 0U;
}

static inline bool is_armv8_3_pauth_present(void)
{
	uint64_t mask_id_aa64isar1 =
		(ID_AA64ISAR1_GPI_MASK << ID_AA64ISAR1_GPI_SHIFT) |
		(ID_AA64ISAR1_GPA_MASK << ID_AA64ISAR1_GPA_SHIFT) |
		(ID_AA64ISAR1_API_MASK << ID_AA64ISAR1_API_SHIFT) |
		(ID_AA64ISAR1_APA_MASK << ID_AA64ISAR1_APA_SHIFT);

	/*
	 * If any of the fields is not zero or QARMA3 is present,
	 * PAuth is present.
	 */
	return ((read_id_aa64isar1_el1() & mask_id_aa64isar1) != 0U ||
		is_feat_pacqarma3_present());
}

static inline bool is_armv8_3_pauth_apa_api_apa3_present(void)
{
	uint64_t mask_id_aa64isar1 =
		(ID_AA64ISAR1_API_MASK << ID_AA64ISAR1_API_SHIFT) |
		(ID_AA64ISAR1_APA_MASK << ID_AA64ISAR1_APA_SHIFT);

	uint64_t mask_id_aa64isar2 =
		(ID_AA64ISAR2_APA3_MASK << ID_AA64ISAR2_APA3_SHIFT);

	return ((read_id_aa64isar1_el1() & mask_id_aa64isar1) |
		(read_id_aa64isar2_el1() & mask_id_aa64isar2)) != 0U;
}

static inline bool is_armv8_3_pauth_gpa_gpi_gpa3_present(void)
{
	uint64_t mask_id_aa64isar1 =
		(ID_AA64ISAR1_GPI_MASK << ID_AA64ISAR1_GPI_SHIFT) |
		(ID_AA64ISAR1_GPA_MASK << ID_AA64ISAR1_GPA_SHIFT);

	uint64_t mask_id_aa64isar2 =
		(ID_AA64ISAR2_GPA3_MASK << ID_AA64ISAR2_GPA3_SHIFT);

	return ((read_id_aa64isar1_el1() & mask_id_aa64isar1) |
		(read_id_aa64isar2_el1() & mask_id_aa64isar2)) != 0U;
}

static inline bool is_armv8_4_dit_present(void)
{
	return ((read_id_aa64pfr0_el1() >> ID_AA64PFR0_DIT_SHIFT) &
		ID_AA64PFR0_DIT_MASK) == 1U;
}

static inline bool is_armv8_4_nv2_present(void)
{
	return ((read_id_aa64mmfr2_el1() >> ID_AA64MMFR2_EL1_NV_SHIFT) &
		ID_AA64MMFR2_EL1_NV_MASK) == NV2_IMPLEMENTED;
}

static inline bool is_armv8_4_ttst_present(void)
{
	return ((read_id_aa64mmfr2_el1() >> ID_AA64MMFR2_EL1_ST_SHIFT) &
		ID_AA64MMFR2_EL1_ST_MASK) == 1U;
}

static inline bool is_armv8_5_bti_present(void)
{
	return ((read_id_aa64pfr1_el1() >> ID_AA64PFR1_EL1_BT_SHIFT) &
		ID_AA64PFR1_EL1_BT_MASK) == BTI_IMPLEMENTED;
}

static inline unsigned int get_armv8_5_mte_support(void)
{
	return ((read_id_aa64pfr1_el1() >> ID_AA64PFR1_EL1_MTE_SHIFT) &
		ID_AA64PFR1_EL1_MTE_MASK);
}

static inline bool is_armv8_6_fgt_present(void)
{
	return (((read_id_aa64mmfr0_el1() >> ID_AA64MMFR0_EL1_FGT_SHIFT) &
		ID_AA64MMFR0_EL1_FGT_MASK) != 0U);
}

static inline bool is_feat_idte3_present(void)
{
	return (((read_id_aa64mmfr2_el1() >> ID_AA64MMFR2_EL1_IDS_SHIFT) &
		ID_AA64MMFR2_EL1_IDS_MASK) == IDTE3_IMPLEMENTED);
}

static inline bool is_armv8_9_fgt2_present(void)
{
	return ((read_id_aa64mmfr0_el1() >> ID_AA64MMFR0_EL1_FGT_SHIFT) &
		ID_AA64MMFR0_EL1_FGT_MASK) == ID_AA64MMFR0_EL1_FGT2_SUPPORTED;
}

static inline unsigned long int get_armv8_6_ecv_support(void)
{
	return ((read_id_aa64mmfr0_el1() >> ID_AA64MMFR0_EL1_ECV_SHIFT) &
		ID_AA64MMFR0_EL1_ECV_MASK);
}

static inline unsigned long int get_pa_range(void)
{
	return ((read_id_aa64mmfr0_el1() >> ID_AA64MMFR0_EL1_PARANGE_SHIFT) &
		ID_AA64MMFR0_EL1_PARANGE_MASK);
}

static inline uint32_t arch_get_debug_version(void)
{
	return ((read_id_aa64dfr0_el1() & ID_AA64DFR0_DEBUG_BITS) >>
		ID_AA64DFR0_DEBUG_SHIFT);
}

static inline bool get_armv8_4_trf_support(void)
{
	return ((read_id_aa64dfr0_el1() >> ID_AA64DFR0_TRACEFILT_SHIFT) &
		ID_AA64DFR0_TRACEFILT_MASK) ==
		ID_AA64DFR0_TRACEFILT_SUPPORTED;
}

static inline bool get_armv8_0_sys_reg_trace_support(void)
{
	return ((read_id_aa64dfr0_el1() >> ID_AA64DFR0_TRACEVER_SHIFT) &
		ID_AA64DFR0_TRACEVER_MASK) ==
		ID_AA64DFR0_TRACEVER_SUPPORTED;
}

static inline unsigned int get_armv9_2_feat_rme_support(void)
{
	/*
	 * Return the RME version, zero if not supported.  This function can be
	 * used as both an integer value for the RME version or compared to zero
	 * to detect RME presence.
	 */
	return (unsigned int)(read_id_aa64pfr0_el1() >>
		ID_AA64PFR0_FEAT_RME_SHIFT) & ID_AA64PFR0_FEAT_RME_MASK;
}

static inline bool get_feat_hcx_support(void)
{
	return (((read_id_aa64mmfr1_el1() >> ID_AA64MMFR1_EL1_HCX_SHIFT) &
		ID_AA64MMFR1_EL1_HCX_MASK) == ID_AA64MMFR1_EL1_HCX_SUPPORTED);
}

static inline bool get_feat_afp_present(void)
{
	return (((read_id_aa64mmfr1_el1() >> ID_AA64MMFR1_EL1_AFP_SHIFT) &
		  ID_AA64MMFR1_EL1_AFP_MASK) == ID_AA64MMFR1_EL1_AFP_SUPPORTED);
}

static inline bool get_feat_brbe_support(void)
{
	return ((read_id_aa64dfr0_el1() >> ID_AA64DFR0_BRBE_SHIFT) &
		ID_AA64DFR0_BRBE_MASK) >=
		ID_AA64DFR0_BRBE_SUPPORTED;
}

static inline bool get_feat_wfxt_present(void)
{
	return (((read_id_aa64isar2_el1() >> ID_AA64ISAR2_WFXT_SHIFT) &
		ID_AA64ISAR2_WFXT_MASK) == ID_AA64ISAR2_WFXT_SUPPORTED);
}

static inline bool is_feat_rng_present(void)
{
	return (((read_id_aa64isar0_el1() >> ID_AA64ISAR0_RNDR_SHIFT) &
			ID_AA64ISAR0_RNDR_MASK)
			>= ID_AA64ISAR0_RNDR_SUPPORTED);
}

static inline bool is_feat_rng_trap_present(void)
{
	return (((read_id_aa64pfr1_el1() >> ID_AA64PFR1_EL1_RNDR_TRAP_SHIFT) &
			ID_AA64PFR1_EL1_RNDR_TRAP_MASK)
			== ID_AA64PFR1_EL1_RNG_TRAP_SUPPORTED);
}

static inline bool is_feat_mpam_supported(void)
{
	/*
	 * If the MPAM version retreived from the Processor Feature registers
	 * is a non-zero value, then MPAM is supported.
	 */

	return (((((read_id_aa64pfr0_el1() >>
		ID_AA64PFR0_MPAM_SHIFT) & ID_AA64PFR0_MPAM_MASK) << 4) |
		((read_id_aa64pfr1_el1() >>
		ID_AA64PFR1_MPAM_FRAC_SHIFT) & ID_AA64PFR1_MPAM_FRAC_MASK)) != 0U);
}

static inline bool is_feat_mpam_pe_bw_ctrl_supported(void)
{
	return (is_feat_mpam_supported() &&
			(EXTRACT(MPAMIDR_HAS_BW_CTRL, read_mpamidr_el1()) != 0U));
}

static inline unsigned int spe_get_version(void)
{
	return (unsigned int)((read_id_aa64dfr0_el1() >> ID_AA64DFR0_PMS_SHIFT) &
		ID_AA64DFR0_PMS_MASK);
}

static inline bool is_feat_spe_supported(void)
{
	return spe_get_version() >= ID_AA64DFR0_SPE;
}

static inline bool is_feat_tcr2_supported(void)
{
	return (((read_id_aa64mmfr3_el1() >> ID_AA64MMFR3_EL1_TCRX_SHIFT) &
		ID_AA64MMFR3_EL1_TCRX_MASK) >= ID_AA64MMFR3_EL1_TCR2_SUPPORTED);
}

static inline bool get_feat_pmuv3_supported(void)
{
	return (((read_id_aa64dfr0_el1() >> ID_AA64DFR0_PMUVER_SHIFT) &
		ID_AA64DFR0_PMUVER_MASK) != ID_AA64DFR0_PMUVER_NOT_SUPPORTED);
}

static inline bool is_feat_pmuv3p9_present(void)
{
	return (((read_id_aa64dfr0_el1() >> ID_AA64DFR0_PMUVER_SHIFT) &
		ID_AA64DFR0_PMUVER_MASK) >= ID_AA64DFR0_PMUVER_V3P9_SUPPORTED);
}

static inline bool get_feat_hpmn0_supported(void)
{
	return (((read_id_aa64dfr0_el1() >> ID_AA64DFR0_HPMN0_SHIFT) &
		ID_AA64DFR0_HPMN0_MASK) == ID_AA64DFR0_HPMN0_SUPPORTED);
}

static inline bool is_feat_sme_supported(void)
{
	uint64_t features;

	features = read_id_aa64pfr1_el1() >> ID_AA64PFR1_EL1_SME_SHIFT;
	return (features & ID_AA64PFR1_EL1_SME_MASK) >= ID_AA64PFR1_EL1_SME_SUPPORTED;
}

static inline bool is_feat_sme_fa64_supported(void)
{
	uint64_t features;

	features = read_id_aa64smfr0_el1();
	return (features & ID_AA64SMFR0_EL1_FA64_BIT) != 0U;
}

static inline bool is_feat_sme2_supported(void)
{
	uint64_t features;

	features = read_id_aa64pfr1_el1() >> ID_AA64PFR1_EL1_SME_SHIFT;
	return (features & ID_AA64PFR1_EL1_SME_MASK) >= ID_AA64PFR1_EL1_SME2_SUPPORTED;
}

/* Check if extended breakpoints are available part of Debugv8p9 */
static inline bool is_feat_debugv8p9_ebwe_supported(void)
{
	return EXTRACT(ID_AA64DFR1_BRP, read_id_aa64dfr1_el1()) != 0U;
}

static inline u_register_t get_id_aa64mmfr0_el0_tgran4(void)
{
	return EXTRACT(ID_AA64MMFR0_EL1_TGRAN4, read_id_aa64mmfr0_el1());
}

static inline u_register_t get_id_aa64mmfr0_el0_tgran4_2(void)
{
	return EXTRACT(ID_AA64MMFR0_EL1_TGRAN4_2, read_id_aa64mmfr0_el1());
}

static inline u_register_t get_id_aa64mmfr0_el0_tgran16(void)
{
	return EXTRACT(ID_AA64MMFR0_EL1_TGRAN16, read_id_aa64mmfr0_el1());
}

static inline u_register_t get_id_aa64mmfr0_el0_tgran16_2(void)
{
	return EXTRACT(ID_AA64MMFR0_EL1_TGRAN16_2, read_id_aa64mmfr0_el1());
}

static inline u_register_t get_id_aa64mmfr0_el0_tgran64(void)
{
	return EXTRACT(ID_AA64MMFR0_EL1_TGRAN64, read_id_aa64mmfr0_el1());
}

static inline u_register_t get_id_aa64mmfr0_el0_tgran64_2(void)
{
	return EXTRACT(ID_AA64MMFR0_EL1_TGRAN64_2, read_id_aa64mmfr0_el1());
}

static inline bool is_feat_52b_on_4k_supported(void)
{
	return (get_id_aa64mmfr0_el0_tgran4() ==
				ID_AA64MMFR0_EL1_TGRAN4_52B_SUPPORTED);
}

static inline bool is_feat_52b_on_4k_2_supported(void)
{
	u_register_t tgran4_2 = get_id_aa64mmfr0_el0_tgran4_2();

	return ((tgran4_2 == ID_AA64MMFR0_EL1_TGRAN4_2_52B_SUPPORTED) ||
		((tgran4_2 == ID_AA64MMFR0_EL1_TGRAN4_2_AS_1)
			&& (is_feat_52b_on_4k_supported() == true)));
}

static inline bool is_feat_specres_present(void)
{
	return EXTRACT(ID_AA64ISAR1_SPECRES, read_id_aa64isar1_el1())
		== ID_AA64ISAR1_SPECRES_SUPPORTED;
}

static inline bool is_feat_tlbirange_present(void)
{
	return EXTRACT(ID_AA64ISAR0_TLB, read_id_aa64isar0_el1())
		== ID_AA64ISAR0_TLBIRANGE_SUPPORTED;
}

static inline bool is_feat_tlbios_present(void)
{
	return EXTRACT(ID_AA64ISAR0_TLB, read_id_aa64isar0_el1())
		!= ID_AA64ISAR0_TLB_NOT_SUPPORTED;
}

static inline bool is_feat_dpb_present(void)
{
	return EXTRACT(ID_AA64ISAR1_DPB, read_id_aa64isar1_el1())
		>= ID_AA64ISAR1_DPB_SUPPORTED;
}

static inline bool is_feat_dpb2_present(void)
{
	return EXTRACT(ID_AA64ISAR1_DPB, read_id_aa64isar1_el1())
		>= ID_AA64ISAR1_DPB2_SUPPORTED;
}

static inline bool is_feat_ls64_present(void)
{
	return EXTRACT(ID_AA64ISAR1_LS64, read_id_aa64isar1_el1())
		>= ID_AA64ISAR1_LS64_SUPPORTED;
}

static inline bool is_feat_ls64_v_present(void)
{
	return EXTRACT(ID_AA64ISAR1_LS64, read_id_aa64isar1_el1())
		>= ID_AA64ISAR1_LS64_V_SUPPORTED;
}

static inline bool is_feat_ls64_accdata_present(void)
{
	return EXTRACT(ID_AA64ISAR1_LS64, read_id_aa64isar1_el1())
		>= ID_AA64ISAR1_LS64_ACCDATA_SUPPORTED;
}

static inline bool is_feat_ras_present(void)
{
	return EXTRACT(ID_AA64PFR0_RAS, read_id_aa64pfr0_el1())
		>= ID_AA64PFR0_RAS_SUPPORTED;
}

static inline bool is_feat_rasv1p1_present(void)
{
	return (EXTRACT(ID_AA64PFR0_RAS, read_id_aa64pfr0_el1())
		== ID_AA64PFR0_RASV1P1_SUPPORTED)
		|| (is_feat_ras_present() &&
			(EXTRACT(ID_AA64PFR1_RAS_FRAC, read_id_aa64pfr1_el1())
				== ID_AA64PFR1_RASV1P1_SUPPORTED))
		|| (EXTRACT(ID_PFR0_EL1_RAS, read_id_pfr0_el1())
			== ID_PFR0_EL1_RASV1P1_SUPPORTED)
		|| ((EXTRACT(ID_PFR0_EL1_RAS, read_id_pfr0_el1())
			== ID_PFR0_EL1_RAS_SUPPORTED) &&
			(EXTRACT(ID_PFR2_EL1_RAS_FRAC, read_id_pfr2_el1())
				== ID_PFR2_EL1_RASV1P1_SUPPORTED));
}

static inline bool is_feat_gicv3_gicv4_present(void)
{
	return EXTRACT(ID_AA64PFR0_GIC, read_id_aa64pfr0_el1())
		== ID_AA64PFR0_GICV3_GICV4_SUPPORTED;
}

static inline bool is_feat_csv2_present(void)
{
	return EXTRACT(ID_AA64PFR0_CSV2, read_id_aa64pfr0_el1())
		== ID_AA64PFR0_CSV2_SUPPORTED;
}

static inline bool is_feat_csv2_2_present(void)
{
	return EXTRACT(ID_AA64PFR0_CSV2, read_id_aa64pfr0_el1())
		== ID_AA64PFR0_CSV2_2_SUPPORTED;
}

static inline bool is_feat_csv2_1p1_present(void)
{
	return is_feat_csv2_present() &&
		(EXTRACT(ID_AA64PFR1_CSV2_FRAC, read_id_aa64pfr1_el1())
			== ID_AA64PFR1_CSV2_1P1_SUPPORTED);
}

static inline bool is_feat_csv2_1p2_present(void)
{
	return is_feat_csv2_present() &&
		(EXTRACT(ID_AA64PFR1_CSV2_FRAC, read_id_aa64pfr1_el1())
			== ID_AA64PFR1_CSV2_1P2_SUPPORTED);
}

static inline bool is_feat_lor_present(void)
{
	return EXTRACT(ID_AA64MMFR1_EL1_LO, read_id_aa64mmfr1_el1())
		!= ID_AA64MMFR1_EL1_LOR_NOT_SUPPORTED;
}

static inline unsigned int get_feat_ls64_support(void)
{
	return ((read_id_aa64isar1_el1() >> ID_AA64ISAR1_LS64_SHIFT) &
		ID_AA64ISAR1_LS64_MASK);
}

static inline unsigned int amu_get_version(void)
{
	return (unsigned int)(read_id_aa64pfr0_el1() >> ID_AA64PFR0_AMU_SHIFT) &
		ID_AA64PFR0_AMU_MASK;
}

static inline bool is_feat_amuv1_present(void)
{
	return amu_get_version() >= ID_AA64PFR0_AMU_V1;
}

static inline bool is_feat_amuv1p1_present(void)
{
	return amu_get_version() >= ID_AA64PFR0_AMU_V1P1;
}

static inline bool is_feat_twed_present(void)
{
	return EXTRACT(ID_AA64MMFR1_EL1_TWED, read_id_aa64mmfr1_el1())
		>= ID_AA64MMFR1_EL1_TWED_SUPPORTED;
}

static inline bool is_feat_trbe_present(void)
{
	return EXTRACT(ID_AA64DFR0_TRACEBUFFER, read_id_aa64dfr0_el1())
		>= ID_AA64DFR0_TRACEBUFFER_SUPPORTED;
}

static inline bool is_feat_gcs_present(void)
{
	return EXTRACT(ID_AA64PFR1_EL1_GCS, read_id_aa64pfr1_el1())
		>= ID_AA64PFR1_EL1_GCS_SUPPORTED;
}

static inline bool is_feat_s1poe_present(void)
{
	return EXTRACT(ID_AA64MMFR3_EL1_S1POE, read_id_aa64mmfr3_el1())
		>= ID_AA64MMFR3_EL1_S1POE_SUPPORTED;
}

static inline bool is_feat_s2poe_present(void)
{
	return EXTRACT(ID_AA64MMFR3_EL1_S2POE, read_id_aa64mmfr3_el1())
		>= ID_AA64MMFR3_EL1_S2POE_SUPPORTED;
}

static inline bool is_feat_s1pie_present(void)
{
	return EXTRACT(ID_AA64MMFR3_EL1_S1PIE, read_id_aa64mmfr3_el1())
		>= ID_AA64MMFR3_EL1_S1PIE_SUPPORTED;
}

static inline bool is_feat_s2pie_present(void)
{
	return EXTRACT(ID_AA64MMFR3_EL1_S2PIE, read_id_aa64mmfr3_el1())
		>= ID_AA64MMFR3_EL1_S2PIE_SUPPORTED;
}

static inline bool is_feat_sxpoe_present(void)
{
	return is_feat_s1poe_present() || is_feat_s2poe_present();
}

static inline bool is_feat_sxpie_present(void)
{
	return is_feat_s1pie_present() || is_feat_s2pie_present();
}

static inline bool is_feat_mte2_present(void)
{
	return EXTRACT(ID_AA64PFR1_EL1_MTE, read_id_aa64pfr1_el1())
		>= MTE_IMPLEMENTED_ELX;
}

static inline bool is_feat_double_fault2_present(void)
{
	return (EXTRACT(ID_AA64PFR1_EL1_DF2,
		read_id_aa64pfr1_el1()) == 1UL);
}

static inline bool is_feat_fpmr_present(void)
{
	return EXTRACT(ID_AA64PFR2_EL1_FPMR, read_id_aa64pfr2_el1())
		== ID_AA64PFR2_EL1_FPMR_SUPPORTED;
}

static inline bool is_feat_sctlr2_supported(void)
{
	return (((read_id_aa64mmfr3_el1() >> ID_AA64MMFR3_EL1_SCTLRX_SHIFT) &
		ID_AA64MMFR3_EL1_SCTLRX_MASK) == ID_AA64MMFR3_EL1_SCTLR2_SUPPORTED);
}

static inline bool is_feat_the_supported(void)
{
	return (((read_id_aa64pfr1_el1() >> ID_AA64PFR1_EL1_THE_SHIFT) &
		ID_AA64PFR1_EL1_THE_MASK) == ID_AA64PFR1_EL1_THE_SUPPORTED);
}

static inline bool is_feat_d128_supported(void)
{
	return (((read_id_aa64mmfr3_el1() >> ID_AA64MMFR3_EL1_D128_SHIFT) &
		ID_AA64MMFR3_EL1_D128_MASK) == ID_AA64MMFR3_EL1_D128_SUPPORTED);
}

static inline bool is_feat_doublelock_present(void)
{
	return EXTRACT(ID_AA64DFR0_DOUBLELOCK, read_id_aa64dfr0_el1())
			>= DOUBLELOCK_IMPLEMENTED;
}

static inline bool is_feat_mec_supported(void)
{
	return EXTRACT(ID_AA64MMFR3_EL1_MEC, read_id_aa64mmfr3_el1())
		== ID_AA64MMFR3_EL1_MEC_SUPPORTED;
}

static inline bool is_feat_aie_supported(void)
{
	return EXTRACT(ID_AA64MMFR3_EL1_AIE, read_id_aa64mmfr3_el1())
		== ID_AA64MMFR3_EL1_AIE_SUPPORTED;
}

static inline bool is_feat_pfar_supported(void)
{
	return EXTRACT(ID_AA64PFR1_EL1_PFAR, read_id_aa64pfr1_el1())
		== ID_AA64PFR1_EL1_PFAR_SUPPORTED;
}

static inline bool is_feat_gic_supported(void)
{
	return EXTRACT(ID_AA64PFR0_GIC, read_id_aa64pfr0_el1())
			>= ID_AA64PFR0_GICV3_GICV4_SUPPORTED;
}

static inline bool is_feat_gcie_supported(void)
{
	return EXTRACT(ID_AA64PFR2_EL1_GCIE, read_id_aa64pfr2_el1())
			>= ID_AA64PFR2_EL1_GCIE_SUPPORTED;
}

static inline bool is_feat_ebep_supported(void)
{
	return EXTRACT(ID_AA64DFR1_EBEP, read_id_aa64dfr1_el1())
			>= ID_AA64DFR1_EBEP_SUPPORTED;
}
#endif /* ARCH_FEATURES_H */
