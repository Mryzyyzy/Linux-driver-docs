/*
 * Copyright (c) 2022-2025, Arm Limited. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#ifndef HOST_REALM_HELPER_H
#define HOST_REALM_HELPER_H

#include <stdlib.h>
#include <arch_features.h>
#include <debug.h>
#include <host_realm_rmi.h>
#include <spinlock.h>
#include <tftf_lib.h>

/*
 * Creates realm, initializes heap and creates RTTs
 */
bool host_prepare_realm_payload(struct realm *realm_ptr,
		u_register_t realm_payload_adr,
		u_register_t feature_flag0,
		u_register_t feature_flag1,
		long sl,
		const u_register_t *rec_flag,
		unsigned int rec_count,
		unsigned int num_aux_planes,
		unsigned short mecid);

/*
 * Creates realm, initializes heap, creates RTTs and also
 * Creates recs
 */
bool host_create_realm_payload(struct realm *realm_ptr,
		u_register_t realm_payload_adr,
		u_register_t feature_flag0,
		u_register_t feature_flag1,
		long sl,
		const u_register_t *rec_flag,
		unsigned int rec_count,
		unsigned int num_aux_planes,
		unsigned short mecid);

/*
 * Creates realm, initializes heap, creates RTTs,
 * creates recs and activate realm
 */
bool host_create_activate_realm_payload(struct realm *realm_ptr,
		u_register_t realm_payload_adr,
		u_register_t feature_flag0,
		u_register_t feature_flag1,
		long sl,
		const u_register_t *rec_flag,
		unsigned int rec_count,
		unsigned int num_aux_planes,
		unsigned short mecid);
bool host_destroy_realm(struct realm *realm_ptr);
void host_rec_send_sgi(struct realm *realm_ptr,
		unsigned int sgi, unsigned int rec_num);
bool host_enter_realm_execute(struct realm *realm_ptr, uint8_t cmd,
		int test_exit_reason, unsigned int rec_num);
test_result_t host_cmp_result(void);
void realm_print_handler(struct realm *realm_ptr, unsigned int plane_num, unsigned int rec_num);
bool host_ipa_is_ns(u_register_t addr, u_register_t rmm_feat_reg0);

/*
 * This functions sets the shared data args needed for entering aux plane,
 * using REALM_ENTER_PLANE_N_CMD
 */
void host_realm_set_aux_plane_args(struct realm *realm_ptr,
		unsigned int plane_num, unsigned int rec_num);


/* Function to check if Planes feature is supoprted */
static inline bool are_planes_supported(void)
{
	u_register_t feature_flag;

	/* Read Realm Feature Reg 0 */
	if (host_rmi_features(0UL, &feature_flag) != REALM_SUCCESS) {
		ERROR("%s() failed\n", "host_rmi_features");
		return false;
	}

	if (EXTRACT(RMI_FEATURE_REGISTER_0_MAX_NUM_AUX_PLANES, feature_flag) > 0UL) {
		return true;
	}

	return false;
}

/* Function to check if S2POE feature/ Single RTT is supported for multiple planes */
static inline bool is_single_rtt_supported(void)
{
	u_register_t feature_flag;

	/* Read Realm Feature Reg 0 */
	if (host_rmi_features(0UL, &feature_flag) != REALM_SUCCESS) {
		ERROR("%s() failed\n", "host_rmi_features");
		return false;
	}

	if (EXTRACT(RMI_FEATURE_REGISTER_0_PLANE_RTT, feature_flag) != RMI_PLANE_RTT_AUX) {
		return true;
	}

	return false;
}

/* Test helper to retrieve a test MECID */
static inline unsigned short get_test_mecid(void)
{
	static bool inited = false;
	static unsigned short max_mecid = 0, current_mecid;
	static spinlock_t lock;
	unsigned long feat_reg1;

	spin_lock(&lock);

	if (!inited) {
		if (is_feat_mec_supported() &&
				(host_rmi_features(1UL, &feat_reg1) == 0UL &&
				feat_reg1 != 0UL)) {
			max_mecid = (unsigned short)feat_reg1;
		}

		inited = true;
	}
	if(max_mecid != 0) {
		current_mecid++;
		current_mecid %= max_mecid;
	}
	spin_unlock(&lock);
	return current_mecid;

}

/* Handle REC exit due to VDEV request */
void host_do_vdev_complete(u_register_t rec_ptr, unsigned long vdev_id);

/* Handle REC exit due to VDEV communication */
void host_do_vdev_communicate(u_register_t vdev_ptr, unsigned long vdev_action);

#endif /* HOST_REALM_HELPER_H */
